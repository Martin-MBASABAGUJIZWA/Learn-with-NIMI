"use client"

import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useCallback,
  KeyboardEvent,
  ChangeEvent,
} from "react"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import BottomNavigation from "@/components/BottomNavigation"
import Footer from "@/components/Footer"
import {
  MessageCircle,
  Heart,
  Star,
  Upload,
  Camera,
  Mic,
  Crown,
  Sparkles,
  Trophy,
  Send,
  ChevronLeft,
  ChevronRight,
  Copy,
  Whatsapp,
  Facebook,
  X,
  Comment,
} from "lucide-react"
import { useLanguage } from "@/contexts/LanguageContext"
import { motion, AnimatePresence } from "framer-motion"
import useSWR from "swr"
import { useForm } from "react-hook-form"

import { create } from "zustand";

// -------------------
// Global State Management with Zustand
// -------------------

// Typescript Interfaces
interface Creation {
  id: number
  childName: string
  age: number
  creation: string
  type: string
  likes: number
  image: string
  mission: string
  emoji: string
  comments?: CommentType[]
  approved?: boolean // For future moderation system
  createdAt?: string
}

interface CommentType {
  id: number
  creationId: number
  author: string
  content: string
  createdAt?: string
}

interface PikoPal {
  name: string
  age: number
  achievements: number
  streak: number
  avatar: string
  title: string
}

interface CreationsState {
  creations: Creation[]
  pikopals: PikoPal[]
  loadingCreations: boolean
  loadingPals: boolean
  errorCreations: boolean
  errorPals: boolean
  page: number
  totalPages: number
  filterMission: string | null
  filterAge: [number, number] | null
  sortBy: "likes" | "recency" | null
  addCreations: (newCreations: Creation[], page?: number, totalPages?: number) => void
  resetCreations: () => void
  likeCreation: (id: number) => void
  addComment: (creationId: number, comment: CommentType) => void
  setFilterMission: (mission: string | null) => void
  setFilterAge: (ageRange: [number, number] | null) => void
  setSortBy: (sort: "likes" | "recency" | null) => void
  setPage: (page: number) => void
  setPikopals: (pals: PikoPal[]) => void
  setLoadingCreations: (val: boolean) => void
  setLoadingPals: (val: boolean) => void
  setErrorCreations: (val: boolean) => void
  setErrorPals: (val: boolean) => void
}

const useCreationsStore = create<CreationsState>((set, get) => ({
  creations: [],
  pikopals: [],
  loadingCreations: true,
  loadingPals: true,
  errorCreations: false,
  errorPals: false,
  page: 1,
  totalPages: 1,
  filterMission: null,
  filterAge: null,
  sortBy: null,
  addCreations: (newCreations, page, totalPages) => {
    set((state) => ({
      creations:
        page && page > 1
          ? [...state.creations, ...newCreations]
          : newCreations,
      page: page || 1,
      totalPages: totalPages || state.totalPages,
      loadingCreations: false,
      errorCreations: false,
    }))
  },
  resetCreations: () =>
    set({ creations: [], page: 1, totalPages: 1, loadingCreations: true }),
  likeCreation: (id) => {
    set((state) => {
      const newCreations = state.creations.map((c) =>
        c.id === id ? { ...c, likes: c.likes + 1 } : c
      )
      return { creations: newCreations }
    })
  },
  addComment: (creationId, comment) => {
    set((state) => {
      const updatedCreations = state.creations.map((c) => {
        if (c.id === creationId) {
          const existingComments = c.comments || []
          return { ...c, comments: [...existingComments, comment] }
        }
        return c
      })
      return { creations: updatedCreations }
    })
  },
  setFilterMission: (mission) => set({ filterMission: mission }),
  setFilterAge: (ageRange) => set({ filterAge: ageRange }),
  setSortBy: (sort) => set({ sortBy: sort }),
  setPage: (page) => set({ page }),
  setPikopals: (pals) => set({ pikopals: pals, loadingPals: false, errorPals: false }),
  setLoadingCreations: (val) => set({ loadingCreations: val }),
  setLoadingPals: (val) => set({ loadingPals: val }),
  setErrorCreations: (val) => set({ errorCreations: val }),
  setErrorPals: (val) => set({ errorPals: val }),
}))

// -------------------
// Fetcher function for SWR
// -------------------
const fetcher = (url: string) => fetch(url).then((res) => res.json())

// -------------------
// Utility function for debounce (e.g. for input or filters)
// -------------------
function debounce(fn: (...args: any[]) => void, ms = 300) {
  let timeoutId: NodeJS.Timeout
  return function (...args: any[]) {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => fn(...args), ms)
  }
}

// -------------------
// Reusable CreationCard Component
// -------------------
interface CreationCardProps {
  creation: Creation
  onClick: (creation: Creation) => void
  onLike: (id: number) => Promise<void>
}

const CreationCard: React.FC<CreationCardProps> = ({
  creation,
  onClick,
  onLike,
}) => {
  const [likeAnimating, setLikeAnimating] = useState(false)

  const handleLike = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation()
    if (likeAnimating) return
    setLikeAnimating(true)
    await onLike(creation.id)
    setTimeout(() => setLikeAnimating(false), 800)
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      tabIndex={0}
      role="button"
      aria-label={`${creation.creation} by ${creation.childName}, age ${creation.age}, mission: ${creation.mission}`}
      onClick={() => onClick(creation)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault()
          onClick(creation)
        }
      }}
      className="bg-white dark:bg-gray-800 border-none shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 overflow-hidden rounded-lg cursor-pointer outline-none focus:ring-4 focus:ring-pink-500 dark:focus:ring-pink-400 focus:ring-offset-1 focus:ring-offset-white dark:focus:ring-offset-gray-900"
    >
      <div className="relative">
        <img
          src={creation.image || "/placeholder.svg"}
          alt={creation.creation}
          className="w-full h-48 object-cover"
          loading="lazy"
        />
        <div
          className="absolute top-2 right-2 text-3xl select-none"
          aria-hidden="true"
          title={creation.emoji + " emoji"}
        >
          {creation.emoji}
        </div>
        <div className="absolute bottom-2 left-2">
          <Badge className="bg-white/90 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-semibold">
            {creation.type}
          </Badge>
        </div>
      </div>
      <CardContent className="p-4">
        <h3 className="font-bold text-gray-800 dark:text-gray-100 mb-2">
          {creation.creation}
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
          {`by ${creation.childName}, ${creation.age} ${creation.age === 1 ? "year" : "years"}`}
        </p>
        <p className="text-xs text-purple-600 dark:text-purple-400 mb-3">
          from {creation.mission}
        </p>
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 1.3 }}
            onClick={handleLike}
            aria-label={`Like creation ${creation.creation}`}
            className="bg-gradient-to-r from-red-400 to-pink-400 hover:from-red-500 hover:to-pink-500 text-white rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-pink-600 focus:ring-offset-1 focus:ring-offset-white dark:focus:ring-offset-gray-900"
          >
            <motion.span
              animate={
                likeAnimating
                  ? {
                      scale: [1, 1.4, 1],
                      rotate: [0, 15, -15, 0],
                      transition: { duration: 0.6 },
                    }
                  : {}
              }
              className="flex items-center space-x-1"
            >
              <Heart className="w-4 h-4" />
              <span>{creation.likes}</span>
            </motion.span>
          </motion.button>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            Tap to view
          </span>
        </div>
      </CardContent>
    </motion.div>
  )
}

// -------------------
// CommentList & CommentInput Components
// -------------------
interface CommentListProps {
  comments: CommentType[]
}
const CommentList: React.FC<CommentListProps> = ({ comments }) => {
  if (!comments.length)
    return (
      <p className="text-sm text-gray-500 dark:text-gray-400 italic">
        No comments yet.
      </p>
    )
  return (
    <ul className="space-y-2 max-h-48 overflow-y-auto">
      {comments.map((c) => (
        <li
          key={c.id}
          className="bg-gray-100 dark:bg-gray-700 rounded-xl p-2 text-sm"
        >
          <div className="font-semibold text-gray-700 dark:text-gray-300">
            {c.author}
          </div>
          <div className="text-gray-800 dark:text-gray-200">{c.content}</div>
          <div className="text-xs text-gray-400 dark:text-gray-500 text-right">
            {new Date(c.createdAt || "").toLocaleString()}
          </div>
        </li>
      ))}
    </ul>
  )
}

interface CommentInputProps {
  creationId: number
  onAddComment: (creationId: number, content: string) => Promise<void>
}

const CommentInput: React.FC<CommentInputProps> = ({
  creationId,
  onAddComment,
}) => {
  const [commentText, setCommentText] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = async () => {
    if (!commentText.trim()) return
    setSubmitting(true)
    await onAddComment(creationId, commentText.trim())
    setCommentText("")
    setSubmitting(false)
    inputRef.current?.focus()
  }

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div className="mt-2 flex items-center space-x-2">
      <input
        ref={inputRef}
        type="text"
        aria-label="Add comment"
        className="flex-grow p-2 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500"
        placeholder="Add a comment..."
        value={commentText}
        onChange={(e: ChangeEvent<HTMLInputElement>) =>
          setCommentText(e.target.value)
        }
        onKeyDown={onKeyDown}
        disabled={submitting}
      />
      <Button
        onClick={handleSubmit}
        disabled={submitting || !commentText.trim()}
        aria-label="Submit comment"
        className="bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-full px-4 py-2"
      >
        <Send className="w-5 h-5" />
      </Button>
    </div>
  )
}

// -------------------
// UploadModal with image preview and upload
// -------------------
interface UploadModalProps {
  onClose: () => void
  childName: string
  onUploadSuccess: (newCreation: Creation) => void
}

const UploadModal: React.FC<UploadModalProps> = ({
  onClose,
  childName,
  onUploadSuccess,
}) => {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [description, setDescription] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const inputFileRef = useRef<HTMLInputElement>(null)
  const { t } = useLanguage()

  // Accessibility: Trap focus inside modal
  const modalRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const focusableElements =
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    const handleFocus = (e: KeyboardEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        e.preventDefault()
        // Focus first element within modal
        const first = modalRef.current.querySelectorAll(focusableElements)[0]
        ;(first as HTMLElement).focus()
      }
    }
    document.addEventListener("focus", handleFocus, true)
    return () => document.removeEventListener("focus", handleFocus, true)
  }, [])

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }

    const objectUrl = URL.createObjectURL(file)
    setPreview(objectUrl)

    return () => URL.revokeObjectURL(objectUrl)
  }, [file])

  const onSelectFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      setFile(null)
      return
    }
    setFile(e.target.files[0])
  }

  const handleUpload = async () => {
    if (!file || !description.trim()) {
      setError(t("uploadErrorFillFields"))
      return
    }
    setError(null)
    setLoading(true)

    try {
      // Prepare form-data payload for image upload
      // This assumes backend is setup to handle multipart/form-data
      const formData = new FormData()
      formData.append("image", file)
      formData.append("description", description.trim())
      formData.append("childName", childName)
      // Placeholder for AI-generated image description for accessibility
      // TODO: Integrate AI image description generation here once backend available
      formData.append("aiDescription", "")

      // Placeholder: Adjust endpoint to your real /api/creations POST endpoint
      const res = await fetch("/api/creations", {
        method: "POST",
        body: formData,
      })
      if (!res.ok) {
        throw new Error("Upload failed")
      }

      const newCreation: Creation = await res.json()
      // Add the new creation to global state and close modal
      onUploadSuccess(newCreation)

      // Animate success: can show confetti or scale up message
      // For simplicity, we'll just alert
      // (Replace with framer-motion confetti animation if you want)
      alert(t("uploadSuccess"))

      onClose()
    } catch {
      setError(t("uploadError"))
      setLoading(false)
    }
  }

  return (
    <div
      className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="upload-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <Card
        className="bg-white dark:bg-gray-900 max-w-md w-full max-h-[90vh] overflow-auto rounded-lg focus:outline-none focus:ring-4 focus:ring-pink-500 dark:focus:ring-pink-400 p-4"
        ref={modalRef}
        tabIndex={-1}
      >
        <CardHeader className="flex justify-between items-center pb-3">
          <CardTitle id="upload-modal-title" className="text-center flex-grow">
            {t("shareCreation")}
          </CardTitle>
          <button
            onClick={onClose}
            aria-label={t("close")}
            className="text-gray-700 dark:text-gray-300 hover:text-pink-600 dark:hover:text-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-500 rounded"
          >
            <X className="w-6 h-6" />
          </button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer focus:outline-none focus:ring-2 focus:ring-pink-500"
            onClick={() => inputFileRef.current?.click()}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault()
                inputFileRef.current?.click()
              }
            }}
            role="button"
            tabIndex={0}
            aria-label={t("uploadPickerAria")}
          >
            {!preview ? (
              <>
                <Camera className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-3" />
                <p className="text-gray-600 dark:text-gray-400">{t("uploadPrompt")}</p>
              </>
            ) : (
              <img
                src={preview}
                alt={description || t("uploadedImage")}
                className="max-h-48 rounded-md"
              />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={onSelectFile}
              className="hidden"
              ref={inputFileRef}
              aria-hidden="true"
            />
          </div>

          <textarea
            aria-label={t("creationDescription")}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t("creationDescription")}
            rows={3}
            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg resize-none dark:bg-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500"
          ></textarea>
          {error && (
            <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
          )}
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-400"
            >
              {t("cancel")}
            </Button>
            <Button
              onClick={handleUpload}
              className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500 text-white"
              disabled={loading}
              aria-busy={loading}
            >
              {loading ? t("uploading") + "..." : t("shareButton")}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// -------------------
// DetailModal for Creation detail + likes + comments + social share
// -------------------
interface DetailModalProps {
  creation: Creation
  onClose: () => void
  onLike: (id: number) => Promise<void>
  onAddComment: (creationId: number, content: string) => Promise<void>
}

const DetailModal: React.FC<DetailModalProps> = ({
  creation,
  onClose,
  onLike,
  onAddComment,
}) => {
  const [likeAnimating, setLikeAnimating] = useState(false)
  const [showCopied, setShowCopied] = useState(false)
  const { t } = useLanguage()

  const handleLike = async () => {
    if (likeAnimating) return
    setLikeAnimating(true)
    await onLike(creation.id)
    setTimeout(() => setLikeAnimating(false), 800)
  }

  const copyLink = () => {
    if (typeof window === "undefined") return
    navigator.clipboard.writeText(window.location.href + `?creation=${creation.id}`)
    setShowCopied(true)
    setTimeout(() => setShowCopied(false), 1500)
  }

  // Social sharing URLs
  const shareUrl = encodeURIComponent(
    typeof window !== "undefined" ? window.location.href + `?creation=${creation.id}` : ""
  )
  const shareText = encodeURIComponent(
    `${creation.creation} by ${creation.childName}, age ${creation.age} - from mission: ${creation.mission}`
  )

  return (
    <motion.div
      className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="detail-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1, transition: { duration: 0.3 } }}
        exit={{ scale: 0.8, opacity: 0 }}
        tabIndex={-1}
        className="bg-white dark:bg-gray-900 rounded-lg shadow-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto outline-none focus:ring-4 focus:ring-pink-500 dark:focus:ring-pink-400"
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
          <h2
            id="detail-modal-title"
            className="text-2xl font-bold text-gray-900 dark:text-gray-100"
          >
            {creation.creation}
          </h2>
          <button
            onClick={onClose}
            aria-label={t("close")}
            className="text-gray-700 dark:text-gray-300 hover:text-pink-600 dark:hover:text-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-500 rounded"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex justify-center items-center">
            <img
              src={creation.image || "/placeholder.svg"}
              alt={creation.creation}
              className="max-h-[350px] rounded-lg object-contain"
              loading="lazy"
            />
          </div>

          <div className="flex flex-col space-y-4 text-gray-800 dark:text-gray-200">
            <p className="whitespace-pre-line">{creation.creation}</p>
            <p>
              <strong>{t("childName")}:</strong> {creation.childName}
            </p>
            <p>
              <strong>{t("childAge")}:</strong> {creation.age}{" "}
              {creation.age === 1 ? t("year") : t("years")}
            </p>
            <p>
              <strong>{t("mission")}:</strong> {creation.mission}
            </p>

            <motion.button
              whileTap={{ scale: 1.3 }}
              onClick={handleLike}
              aria-label={t("likeCreation", { creation: creation.creation })}
              className="bg-gradient-to-r from-red-400 to-pink-400 hover:from-red-500 hover:to-pink-500 text-white rounded-full px-6 py-3 focus:outline-none focus:ring-2 focus:ring-pink-600"
            >
              <motion.span
                animate={
                  likeAnimating
                    ? {
                        scale: [1, 1.4, 1],
                        rotate: [0, 15, -15, 0],
                        transition: { duration: 0.6 },
                      }
                    : {}
                }
                className="flex items-center space-x-2 justify-center font-semibold text-lg"
              >
                <Heart className="w-6 h-6" />
                <span>{creation.likes}</span>
              </motion.span>
            </motion.button>

            {/* Comments Section */}
            <section aria-label={t("commentsSection")}>
              <h3 className="text-xl font-semibold mb-2">{t("comments")}</h3>
              <CommentList comments={creation.comments || []} />
              <CommentInput
                creationId={creation.id}
                onAddComment={onAddComment}
              />
            </section>

            {/* Social Sharing */}
            <section aria-label={t("socialSharing")}>
              <h3 className="text-xl font-semibold mb-2">{t("share")}</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() =>
                    window.open(
                      `https://api.whatsapp.com/send?text=${shareText}%20${shareUrl}`,
                      "_blank",
                      "noopener noreferrer"
                    )
                  }
                  aria-label={t("shareWhatsapp")}
                  className="p-2 rounded-full bg-green-500 hover:bg-green-600 text-white focus:outline-none focus:ring-2 focus:ring-green-600"
                >
                  <Whatsapp className="w-6 h-6" />
                </button>
                <button
                  onClick={() =>
                    window.open(
                      `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`,
                      "_blank",
                      "noopener noreferrer"
                    )
                  }
                  aria-label={t("shareFacebook")}
                  className="p-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-700"
                >
                  <Facebook className="w-6 h-6" />
                </button>
                <button
                  onClick={copyLink}
                  aria-label={t("copyLink")}
                  className="p-2 rounded-full bg-gray-600 hover:bg-gray-700 text-white relative focus:outline-none focus:ring-2 focus:ring-gray-700"
                >
                  <Copy className="w-6 h-6" />
                  <AnimatePresence>
                    {showCopied && (
                      <motion.span
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute -top-6 left-1/2 -translate-x-1/2 rounded bg-black bg-opacity-75 text-xs text-white px-2 py-1 pointer-events-none select-none"
                      >
                        {t("copied")}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </button>
              </div>
            </section>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

// -------------------
// Main CommunityPage Component
// -------------------
export default function CommunityPage() {
  const {
    creations,
    pikopals,
    addCreations,
    resetCreations,
    likeCreation,
    addComment,
    page,
    totalPages,
    setPage,
    filterMission,
    setFilterMission,
    filterAge,
    setFilterAge,
    sortBy,
    setSortBy,
    loadingCreations,
    loadingPals,
    errorCreations,
    errorPals,
    setPikopals,
    setLoadingCreations,
    setLoadingPals,
    setErrorCreations,
    setErrorPals,
  } = useCreationsStore()
  const [selectedCreation, setSelectedCreation] = useState<Creation | null>(null)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const { t, language } = useLanguage()

  // Dynamic child name, fetch from context or fallback (simplified here)
  const childNameFromContext = "Emma" // Placeholder - implement real context or props if available

  const creationsContainerRef = useRef<HTMLDivElement>(null)
  const [isFetchingMore, setIsFetchingMore] = useState(false)

  // Fetch Creations with filtering, sorting, and pagination
  const fetchCreations = useCallback(
    async (pageToLoad = 1, append = false) => {
      setLoadingCreations(true)
      try {
        // Prepare query parameters for filters and sort
        const params = new URLSearchParams()
        params.append("page", pageToLoad.toString())
        if (filterMission) params.append("mission", filterMission)
        if (filterAge) params.append("ageMin", filterAge[0].toString())
        if (filterAge) params.append("ageMax", filterAge[1].toString())
        if (sortBy) params.append("sortBy", sortBy === "recency" ? "createdAt" : sortBy)
        // Placeholder for backend API that accepts these filters/pagination
        const res = await fetch(`/api/creations?${params.toString()}`)
        if (!res.ok) throw new Error("Failed to load creations")
        const data = await res.json()
        const { creations: newCreations, totalPages: tp } = data
        addCreations(newCreations, pageToLoad, tp)
        setErrorCreations(false)
      } catch (error) {
        setErrorCreations(true)
      } finally {
        setLoadingCreations(false)
      }
    },
    [addCreations, filterMission, filterAge, sortBy, setErrorCreations, setLoadingCreations]
  )

  // Fetch PikoPals data
  const fetchPikoPals = useCallback(async () => {
    setLoadingPals(true)
    try {
      // Placeholder for backend endpoint /api/pikopals
      const res = await fetch("/api/pikopals")
      if (!res.ok) throw new Error("Failed to load piko pals")
      const data = await res.json()
      setPikopals(data.pikopals)
      setErrorPals(false)
    } catch {
      setErrorPals(true)
    } finally {
      setLoadingPals(false)
    }
  }, [setErrorPals, setLoadingPals, setPikopals])

  useEffect(() => {
    resetCreations()
    fetchCreations(1)
    fetchPikoPals()
  }, [fetchCreations, fetchPikoPals, resetCreations])

  // Infinite Scroll Handler to load more creations
  useEffect(() => {
    if (!creationsContainerRef.current) return

    const container = creationsContainerRef.current

    const handleScroll = () => {
      if (
        container.scrollTop + container.clientHeight >=
          container.scrollHeight - 200 &&
        !loadingCreations &&
        !isFetchingMore &&
        page < totalPages
      ) {
        setIsFetchingMore(true)
        fetchCreations(page + 1, true).finally(() => setIsFetchingMore(false))
        setPage(page + 1)
      }
    }
    container.addEventListener("scroll", handleScroll)
    return () => container.removeEventListener("scroll", handleScroll)
  }, [
    fetchCreations,
    isFetchingMore,
    loadingCreations,
    page,
    setPage,
    totalPages,
  ])

  // Handle creating new creation from UploadModal
  const handleUploadSuccess = (newCreation: Creation) => {
    // Add new creation at the front
    addCreations([newCreation], 1)
    setShowUploadModal(false)
  }

  // Handle like button click, API integration
  const handleLoveCreation = async (creationId: number) => {
    // Optimistically update UI
    likeCreation(creationId)

    // Integrate API call to increment likes in backend
    try {
      // Placeholder API call
      const res = await fetch(`/api/creations/${creationId}/like`, {
        method: "POST",
      })
      if (!res.ok) throw new Error("Failed to like creation")
    } catch (err) {
      // On failure revert UI change (optional)
      // For simplicity, ignoring revert here
      console.error("Error liking creation:", err)
    }
  }

  // Handle adding comment to creation: call API and update global state
  const handleAddComment = async (
    creationId: number,
    content: string
  ): Promise<void> => {
    try {
      // Placeholder API call to post comment
      const res = await fetch(`/api/creations/${creationId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      })
      if (!res.ok) throw new Error("Failed to add comment")
      const comment: CommentType = await res.json()
      addComment(creationId, comment)
    } catch (err) {
      alert(t("commentError"))
      console.error(err)
    }
  }

  // Filter and Sort options - for UI
  const uniqueMissions = Array.from(
    new Set(creations.map((c) => c.mission))
  ).filter(Boolean)

  // Speech Recognition for NIMI chat voice input - Fallback to browser API
  const [voiceSupported, setVoiceSupported] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [nimiInput, setNimiInput] = useState("")
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", content: t("nimiWelcome") },
  ])
  const [nimiLoading, setNimiLoading] = useState(false)

  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition ||
      null

    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.lang = language || "en-US"
      recognitionRef.current.interimResults = false
      recognitionRef.current.continuous = false
      recognitionRef.current.maxAlternatives = 1
      setVoiceSupported(true)

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript
        setNimiInput((prev) => (prev ? prev + " " + transcript : transcript))
        setIsRecording(false)
      }

      recognitionRef.current.onerror = () => {
        setIsRecording(false)
      }
    }
  }, [language])

  const startVoiceRecording = () => {
    if (!recognitionRef.current) {
      alert(t("voiceNotSupported"))
      return
    }
    if (isRecording) {
      recognitionRef.current.stop()
      setIsRecording(false)
    } else {
      recognitionRef.current.start()
      setIsRecording(true)
    }
  }

  const handleAskNimi = async () => {
    if (!nimiInput.trim()) return
    const newUserMessage = { role: "user", content: nimiInput }
    const updatedMessages = [...chatMessages, newUserMessage]

    setChatMessages(updatedMessages)
    setNimiLoading(true)
    setNimiInput("")

    try {
      const res = await fetch("/api/nimi", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: nimiInput,
          childName: childNameFromContext || "Piko",
          language: language || "en",
        }),
      })

      const data = await res.json()
      const newAssistantMessage = {
        role: "assistant",
        content: data.answer || t("nimiDefaultResponse"),
      }

      setChatMessages((prev) => [...prev, newAssistantMessage])
    } catch (err) {
      setChatMessages((prev) => [
        ...prev,
        { role: "assistant", content: t("nimiErrorResponse") },
      ])
    } finally {
      setNimiLoading(false)
    }
  }

  const handleAskEnter = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleAskNimi()
  }

  // Skeleton Loader Component for Creations Grid
  const SkeletonCard = () => (
    <div className="animate-pulse bg-white dark:bg-gray-800 rounded-lg h-64 shadow-lg" />
  )

  // Error Boundary Component for Modals
  class ErrorBoundary extends React.Component<
    { children: React.ReactNode },
    { hasError: boolean }
  > {
    constructor(props: { children: React.ReactNode }) {
      super(props)
      this.state = { hasError: false }
    }
    static getDerivedStateFromError() {
      return { hasError: true }
    }
    componentDidCatch(error: unknown, info: unknown) {
      console.error("Error caught by ErrorBoundary:", error, info)
    }
    render() {
      if (this.state.hasError) {
        return (
          <div className="p-4 bg-red-100 dark:bg-red-700 rounded text-red-700 dark:text-red-300">
            Something went wrong. Please try again later.
          </div>
        )
      }
      return this.props.children
    }
  }

  // Filtering UI: Mission select, Age range inputs, Sort select
  const handleMissionFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilterMission(e.target.value === "" ? null : e.target.value)
  }

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value === "" ? null : (e.target.value as any))
  }

  // Age filter simplified as min and max input
  const [ageMin, setAgeMin] = useState<number>(0)
  const [ageMax, setAgeMax] = useState<number>(10)
  const debouncedSetFilterAge = useRef(
    debounce((min: number, max: number) => {
      if (min > max) {
        setFilterAge(null)
      } else {
        setFilterAge([min, max])
      }
    }, 500)
  ).current

  useEffect(() => {
    debouncedSetFilterAge(ageMin, ageMax)
  }, [ageMin, ageMax, debouncedSetFilterAge])

  // Accessibility: Alt text for emojis: using aria-label with the emoji and description

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 text-gray-900 dark:text-gray-100">
      <Header />

      {/* Decorative emojis with alt labels for accessibility */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div
          className="absolute top-20 left-10 text-pink-300 animate-bounce text-2xl select-none"
          style={{ animationDelay: "0s" }}
          role="img"
          aria-label="Heart emoji"
        >
          💖
        </div>
        <div
          className="absolute top-40 right-20 text-blue-300 animate-bounce text-2xl select-none"
          style={{ animationDelay: "1s" }}
          role="img"
          aria-label="Star emoji"
        >
          🌟
        </div>
        <div
          className="absolute bottom-40 left-20 text-green-300 animate-bounce text-2xl select-none"
          style={{ animationDelay: "2s" }}
          role="img"
          aria-label="Balloon emoji"
        >
          🎈
        </div>
        <div
          className="absolute bottom-20 right-10 text-yellow-300 animate-bounce text-2xl select-none"
          style={{ animationDelay: "0.5s" }}
          role="img"
          aria-label="Sparkles emoji"
        >
          ✨
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <div
            className="text-6xl mb-4 select-none"
            role="img"
            aria-label="Community icon"
          >
            👥
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4 select-text">
            {t("pikoCommunity")}
          </h1>
          <p className="text-xl text-gray-700 dark:text-gray-400 mb-6 select-text">
            {t("shareCelebrate")}
          </p>
        </div>

        {/* Upload Card */}
        <Card className="mb-8 bg-gradient-to-r from-pink-100 to-purple-100 border-none shadow-xl dark:bg-gradient-to-r dark:from-pink-900 dark:to-purple-900">
          <CardHeader>
            <CardTitle className="flex items-center justify-center text-2xl">
              <Upload className="w-8 h-8 mr-3 text-pink-600 dark:text-pink-400" />
              <span>📸 {t("shareCreationTitle")}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
              {t("shareCreationDescription")}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                onClick={() => setShowUploadModal(true)}
                className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-pink-500 dark:focus:ring-pink-400 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900"
                aria-label={t("uploadPhoto")}
              >
                <Camera className="w-6 h-6 mr-3" />📷 {t("uploadPhoto")}
              </Button>
              <Button
                variant="outline"
                className="border-2 border-purple-300 text-purple-700 hover:bg-purple-50 dark:hover:bg-purple-700 dark:border-purple-600 dark:text-purple-400 px-8 py-4 rounded-full text-lg font-semibold bg-white/80 dark:bg-gray-800/80 focus:outline-none focus:ring-4 focus:ring-purple-500 dark:focus:ring-purple-400 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900"
                aria-label={t("recordStory")}
                onClick={() => {
                  // TODO: Implement voice story recording functionality
                  alert(t("featureComingSoon"))
                }}
              >
                <Mic className="w-6 h-6 mr-3" />🎤 {t("recordStory")}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Filters and Sorting */}
        <section
          aria-labelledby="filters-label"
          className="mb-6 flex flex-col md:flex-row md:items-center md:justify-center space-y-4 md:space-y-0 md:space-x-6"
        >
          <div className="flex flex-col w-full max-w-xs">
            <label htmlFor="filter-mission" className="mb-1 font-semibold">
              {t("filterByMission")}
            </label>
            <select
              id="filter-mission"
              value={filterMission || ""}
              onChange={handleMissionFilterChange}
              className="p-2 rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-400"
            >
              <option value="">{t("allMissions")}</option>
              {uniqueMissions.map((mission) => (
                <option key={mission} value={mission}>
                  {mission}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col w-full max-w-xs">
            <label className="mb-1 font-semibold">{t("filterByAge")}</label>
            <div className="flex space-x-2">
              <input
                type="number"
                min={0}
                max={ageMax}
                aria-label={t("minAge")}
                value={ageMin}
                onChange={(e) => {
                  const val = Number(e.target.value)
                  if (!isNaN(val)) setAgeMin(val)
                }}
                className="p-2 w-full rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-400"
                placeholder={t("min")}
              />
              <input
                type="number"
                min={ageMin}
                max={20}
                aria-label={t("maxAge")}
                value={ageMax}
                onChange={(e) => {
                  const val = Number(e.target.value)
                  if (!isNaN(val)) setAgeMax(val)
                }}
                className="p-2 w-full rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-400"
                placeholder={t("max")}
              />
            </div>
          </div>

          <div className="flex flex-col w-full max-w-xs">
            <label htmlFor="sort-by" className="mb-1 font-semibold">
              {t("sortBy")}
            </label>
            <select
              id="sort-by"
              value={sortBy || ""}
              onChange={handleSortChange}
              className="p-2 rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-400"
            >
              <option value="">{t("none")}</option>
              <option value={"likes"}>{t("likes")}</option>
              <option value={"recency"}>{t("recency")}</option>
            </select>
          </div>
        </section>

        {/* Creations Gallery */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-6 text-center flex items-center justify-center select-none">
            <Sparkles
              className="w-8 h-8 mr-3 text-pink-500 dark:text-pink-400"
              aria-hidden="true"
            />
            🎨 {t("creationsGallery")}
            <Heart
              className="w-8 h-8 ml-3 text-red-500 dark:text-red-400"
              aria-hidden="true"
            />
          </h2>
          <div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 h-[600px] overflow-y-auto"
            ref={creationsContainerRef}
            tabIndex={0}
            aria-label={t("creationsList")}
          >
            {loadingCreations && creations.length === 0
              ? Array(8)
                  .fill(null)
                  .map((_, i) => <SkeletonCard key={i} />)
              : creations
                  .filter((c) =>
                    filterMission ? c.mission === filterMission : true
                  )
                  .filter((c) =>
                    filterAge
                      ? c.age >= filterAge[0] && c.age <= filterAge[1]
                      : true
                  )
                  .sort((a, b) => {
                    if (sortBy === "likes") {
                      return b.likes - a.likes
                    }
                    if (sortBy === "recency") {
                      // Sort by createdAt descending if exists, else by id
                      if (a.createdAt && b.createdAt) {
                        return (
                          new Date(b.createdAt).getTime() -
                          new Date(a.createdAt).getTime()
                        )
                      }
                      return b.id - a.id
                    }
                    return 0
                  })
                  .map((creation) => (
                    <CreationCard
                      key={creation.id}
                      creation={creation}
                      onClick={setSelectedCreation}
                      onLike={handleLoveCreation}
                    />
                  ))}

            {loadingCreations && creations.length > 0 && (
              <div className="absolute bottom-0 left-0 w-full text-center text-gray-500 dark:text-gray-400 p-2">
                {t("loadingMore")}
              </div>
            )}
          </div>
          {errorCreations && (
            <p className="mt-4 text-center text-red-600 dark:text-red-400">
              {t("errorLoadingCreations")}
            </p>
          )}
        </div>

        {/* Piko Pals Hall of Fame */}
        <Card className="mb-8 bg-gradient-to-r from-yellow-100 to-orange-100 border-none shadow-xl dark:bg-gradient-to-r dark:from-yellow-900 dark:to-orange-900">
          <CardHeader>
            <CardTitle className="flex items-center justify-center text-2xl select-none">
              <Crown className="w-8 h-8 mr-3 text-yellow-600 dark:text-yellow-400" />👑{" "}
              {t("hallOfFame")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingPals ? (
              <p className="text-center text-gray-600 dark:text-gray-400 animate-pulse">
                {t("loading")}
              </p>
            ) : errorPals ? (
              <p className="text-center text-red-600 dark:text-red-400">
                {t("errorLoadingPals")}
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {pikopals.map((pal, index) => (
                  <div
                    key={index}
                    className="text-center p-6 bg-white/80 dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-yellow-400 dark:focus:ring-yellow-300"
                    tabIndex={0}
                    aria-label={`${pal.name}, age ${pal.age}, title ${pal.title}, achievements ${pal.achievements}, streak ${pal.streak}`}
                    role="article"
                  >
                    <div className="text-6xl mb-4 select-none" aria-hidden="true">
                      {pal.avatar}
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-2">
                      {pal.name}
                    </h3>
                    <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mb-3">
                      {pal.title}
                    </Badge>
                    <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                      <div className="flex items-center justify-center">
                        <Trophy className="w-4 h-4 mr-2 text-yellow-600 dark:text-yellow-400" />
                        <span>
                          {pal.achievements} {t("achievements")}
                        </span>
                      </div>
                      <div className="flex items-center justify-center">
                        <Star className="w-4 h-4 mr-2 text-orange-600 dark:text-orange-400" />
                        <span>
                          {pal.streak} {t("dayStreak")}
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-center space-x-1 mt-3">
                      {[...Array(3)].map((_, i) => (
                        <span
                          key={i}
                          className="text-yellow-400 animate-bounce text-lg select-none"
                          style={{ animationDelay: `${i * 0.2}s` }}
                          aria-hidden="true"
                        >
                          ✨
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ask Nimi Chat Card */}
        <Card className="mb-8 bg-gradient-to-r from-blue-100 to-indigo-100 border-none shadow-xl dark:bg-gradient-to-r dark:from-blue-900 dark:to-indigo-900">
          <CardHeader>
            <CardTitle className="flex items-center justify-center text-2xl select-none">
              <MessageCircle className="w-8 h-8 mr-3 text-blue-600 dark:text-blue-400" />🤖{" "}
              {t("askNimiAnything")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-w-md mx-auto">
              <div
                className="bg-white/90 dark:bg-gray-800 rounded-xl p-4 shadow-lg h-72 overflow-y-auto focus:outline-none"
                aria-live="polite"
                aria-atomic="true"
                tabIndex={0}
              >
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`mb-3 ${
                      msg.role === "user" ? "text-right" : "text-left"
                    }`}
                  >
                    <div
                      className={`inline-block px-4 py-2 rounded-lg ${
                        msg.role === "user"
                          ? "bg-blue-100 dark:bg-blue-700 text-blue-900 dark:text-blue-100"
                          : "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>

              {/* Input and Voice Input */}
              <div className="flex items-center bg-white/80 dark:bg-gray-700 rounded-full p-3 shadow-md">
                <input
                  type="text"
                  value={nimiInput}
                  onChange={(e) => setNimiInput(e.target.value)}
                  onKeyDown={handleAskEnter}
                  placeholder={t("askPlaceholder")}
                  className="flex-1 bg-transparent outline-none placeholder-gray-500 dark:placeholder-gray-400 text-gray-800 dark:text-gray-100"
                  aria-label={t("askInput")}
                />
                <Button
                  onClick={handleAskNimi}
                  disabled={nimiLoading}
                  aria-label={t("send")}
                  className="ml-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-full px-4 py-2 focus:ring-4 focus:ring-blue-400 dark:focus:ring-blue-600"
                >
                  {nimiLoading ? "..." : <Send className="w-5 h-5" />}
                </Button>
                <Button
                  onClick={startVoiceRecording}
                  disabled={!voiceSupported}
                  aria-pressed={isRecording}
                  aria-label={
                    isRecording ? t("stopRecording") : t("startVoiceInput")
                  }
                  variant={isRecording ? "destructive" : "outline"}
                  className="ml-2 focus:ring-4 focus:ring-blue-400 dark:focus:ring-blue-600"
                >
                  <Mic className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Coming Soon Section */}
        <Card className="bg-gradient-to-r from-green-100 to-emerald-100 border-none shadow-xl dark:bg-gradient-to-r dark:from-green-900 dark:to-emerald-900">
          <CardContent className="p-8 text-center">
            <div className="text-6xl mb-4 select-none" role="img" aria-label="Rocket emoji">
              🚀
            </div>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-4">
              {t("comingSoon")}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 text-gray-700 dark:text-gray-300">
              <div className="text-center">
                <div className="text-4xl mb-2 select-none" role="img" aria-label="Video game controller emoji">
                  🎮
                </div>
                <h4 className="font-bold">{t("learningGames")}</h4>
                <p className="text-sm">{t("playWithFriends")}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2 select-none" role="img" aria-label="Video camera emoji">
                  📹
                </div>
                <h4 className="font-bold">{t("videoCalls")}</h4>
                <p className="text-sm">{t("learnWithNimi")}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2 select-none" role="img" aria-label="Trophy emoji">
                  🏆
                </div>
                <h4 className="font-bold">{t("groupChallenges")}</h4>
                <p className="text-sm">{t("teamAdventures")}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Upload Modal */}
      <AnimatePresence>
        {showUploadModal && (
          <ErrorBoundary>
            <UploadModal
              onClose={() => setShowUploadModal(false)}
              childName={childNameFromContext}
              onUploadSuccess={handleUploadSuccess}
            />
          </ErrorBoundary>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedCreation && (
          <ErrorBoundary>
            <DetailModal
              creation={selectedCreation}
              onClose={() => setSelectedCreation(null)}
              onLike={handleLoveCreation}
              onAddComment={handleAddComment}
            />
          </ErrorBoundary>
        )}
      </AnimatePresence>

      <Footer />
      <BottomNavigation />
    </div>
  )
}