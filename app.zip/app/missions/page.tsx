"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import dynamic from "next/dynamic";
import { motion, AnimatePresence } from "framer-motion";
import supabase from "@/lib/supabaseClient";
import confetti from "canvas-confetti";

import Header from "@/components/Header";
import BottomNavigation from "@/components/BottomNavigation";
import Footer from "@/components/Footer";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import NimiAssistant from "@/components/NimiAssistant";

import {
  CheckCircle,
  Clock,
  Star,
  Play,
  Trophy,
  Lock,
  Calendar,
  Zap,
  ChevronRight,
  Award,
  Loader2,
  Flame,
  BookOpen,
  Bookmark,
} from "lucide-react";

interface Mission {
  id: string;
  day_number: number;
  title: string;
  description: string;
  duration: string;
  difficulty: string;
  points: number;
  video_url: string;
  reward_sticker?: string;
  order: number;
  theme?: string;
  emoji?: string;
  archived: boolean;
  mission_date: string;
}

interface DayData {
  day: number;
  title: string;
  theme: string;
  emoji: string;
  missions: Mission[];
}

interface CompletionData {
  mission_id: string;
  completed_at: string;
  stars_earned: number;
}

interface UserProgress {
  current_day: number;
  unlocked_days: number[];
  daily_streak?: number;
  last_completed_date?: string;
  xp: number;
  level: number;
}

interface Storybook {
  id: string;
  day_number: number;
  title: string;
  content: string;
}

const DAILY_GOAL = 5;
const STREAK_MULTIPLIER = 0.12;
const XP_PER_LEVEL = 1000;
const XP_FOR_MISSION = 100;

export default function MissionsPage() {
  /* States */
  const [missionProgram, setMissionProgram] = useState<DayData[]>([]);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [storybook, setStorybook] = useState<Storybook | null>(null);
  const [showStorybook, setShowStorybook] = useState(false);
  const [completions, setCompletions] = useState<CompletionData[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress>({
    current_day: 1,
    unlocked_days: [1],
    daily_streak: 0,
    last_completed_date: "",
    xp: 0,
    level: 1,
  });
  const [loading, setLoading] = useState(true);
  const [showDayCompleteModal, setShowDayCompleteModal] = useState(false);
  const [newlyUnlockedDay, setNewlyUnlockedDay] = useState<number | null>(null);
  const [completionError, setCompletionError] = useState<string | null>(null);
  const [completingMissionId, setCompletingMissionId] = useState<string | null>(null);
  const [openVideo, setOpenVideo] = useState<Mission | null>(null);
  const [nimiMood, setNimiMood] = useState<"happy" | "excited" | "proud" | "default">("default");

  /* Dummy user */
  const user = { id: "user123" };
  const profile = { full_name: "Little Learner" };

  /* Helpers */
  const todayDate = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    return now;
  }, []);

  const getMotivation = useCallback(() => {
    const msgs = [
      "You're a learning star!",
      "Keep up the great work!",
      "You make learning fun!",
      "Keep your streak alive! 🔥",
      "Every day you grow smarter! 🌱",
    ];
    return msgs[Math.floor(Math.random() * msgs.length)];
  }, []);

  const calculateLevelProgress = useCallback((xp: number, level: number) => {
    const xpNeededForNextLevel = level * XP_PER_LEVEL;
    const progress = Math.min((xp / xpNeededForNextLevel) * 100, 100);
    return { progress, xpNeededForNextLevel };
  }, []);

  const filterAndGroupMissions = useCallback((missions: Mission[]) => {
    const active = missions.filter(m => !m.archived);
    const grouped: Record<number, DayData> = {};

    active.forEach(m => {
      if (!grouped[m.day_number]) {
        grouped[m.day_number] = {
          day: m.day_number,
          title: `Day ${m.day_number}`,
          theme: m.theme || "Learning & Fun",
          emoji: m.emoji || "🌟",
          missions: [],
        };
      }
      grouped[m.day_number].missions.push(m);
    });

    for (const d in grouped) {
      grouped[d].missions.sort((a, b) => a.order - b.order);
    }

    return Object.values(grouped).sort((a, b) => a.day - b.day);
  }, []);

  const isMissionLocked = useCallback((mission: Mission) => {
    const md = new Date(mission.mission_date);
    md.setHours(0, 0, 0, 0);
    return md > todayDate;
  }, [todayDate]);

  const isDayLocked = useCallback(
    (dayNumber: number) => {
      const day = missionProgram.find(d => d.day === dayNumber);
      if (!day) return true;
      return day.missions.every(m => isMissionLocked(m));
    },
    [missionProgram, isMissionLocked]
  );

  /* Data Fetching */
  const fetchUserProgress = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from("student_progress")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (error) throw error;
      if (data) {
        setUserProgress({
          current_day: data.current_day ?? 1,
          unlocked_days: data.unlocked_days ?? [1],
          daily_streak: data.daily_streak ?? 0,
          last_completed_date: data.last_completed_date ?? "",
          xp: data.xp ?? 0,
          level: data.level ?? 1,
        });
      }
    } catch (error) {
      console.error("Error fetching user progress:", error);
    }
  }, [user]);

  const fetchMissions = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from("daily_missions")
        .select("*")
        .order("day_number", { ascending: true })
        .order("order", { ascending: true });

      if (error) throw error;
      if (!data) return;

      const grouped = filterAndGroupMissions(data);
      setMissionProgram(grouped);
      setSelectedDay(grouped[0]?.day ?? null);
    } catch (error) {
      console.error("Error fetching missions:", error);
    }
  }, [filterAndGroupMissions]);

  const fetchCompletions = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from("mission_completions")
        .select("*")
        .eq("user_id", user.id);

      if (error) throw error;
      setCompletions(data ?? []);
    } catch (error) {
      console.error("Error fetching completions:", error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  const fetchStorybookByDay = useCallback(async (day: number) => {
    try {
      const { data, error } = await supabase
        .from("storybook")
        .select("*")
        .eq("day_number", day)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      setStorybook(data ?? null);
    } catch (error) {
      console.error("Error fetching storybook:", error);
      setStorybook(null);
    }
  }, []);

  /* Effects */
  useEffect(() => {
    fetchUserProgress();
    fetchMissions();
    fetchCompletions();
  }, [fetchUserProgress, fetchMissions, fetchCompletions]);

  useEffect(() => {
    if (selectedDay !== null) fetchStorybookByDay(selectedDay);
  }, [selectedDay, fetchStorybookByDay]);

  /* Computed Values */
  const completedIds = useMemo(() => new Set(completions.map(c => c.mission_id)), [completions]);
  const currentDayData = useMemo(() => missionProgram.find(d => d.day === selectedDay), [missionProgram, selectedDay]);
  const totalMissions = currentDayData?.missions.length ?? 0;
  const completedCount = currentDayData?.missions.filter(m => completedIds.has(m.id)).length ?? 0;
  const progressPercent = totalMissions === 0 ? 0 : Math.round((completedCount / totalMissions) * 100);

  const streak = useMemo(() => {
    if (!userProgress.daily_streak || !userProgress.last_completed_date || !completions.length) return 0;
    const lastDate = new Date(userProgress.last_completed_date);
    const today = new Date();
    const daysDiff = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff <= 1 ? userProgress.daily_streak : 0;
  }, [userProgress, completions]);

  const dailyGoalProgress = useMemo(() => {
    if (completions.length === 0) return 0;
    const todayStr = new Date().toDateString();
    const todayCompletedCount = completions.filter(c => 
      new Date(c.completed_at).toDateString() === todayStr
    ).length;
    return Math.min(todayCompletedCount, DAILY_GOAL);
  }, [completions]);

  const { progress: levelProgress, xpNeededForNextLevel } = useMemo(() => 
    calculateLevelProgress(userProgress.xp, userProgress.level),
    [userProgress.xp, userProgress.level]
  );

  /* Mission Completion */
  const completeMission = async (mission: Mission) => {
    if (!user?.id) {
      setCompletionError("You must be logged in to complete missions");
      return;
    }
    if (completedIds.has(mission.id)) {
      setCompletionError("Mission already completed");
      return;
    }

    setCompletionError(null);
    setCompletingMissionId(mission.id);
    setNimiMood("excited");

    const basePoints = mission.points;
    const streakBonus = Math.floor(basePoints * streak * STREAK_MULTIPLIER);
    const totalPoints = basePoints + streakBonus;
    const xpEarned = XP_FOR_MISSION * (1 + streak * 0.1);

    try {
      const { data, error } = await supabase.rpc("complete_mission", {
        user_id: user.id,
        mission_id: mission.id,
        points_earned: totalPoints,
        xp_earned: xpEarned,
        current_day: userProgress.current_day,
        unlocked_days: userProgress.unlocked_days,
      });

      if (error) throw error;

      setCompletions(prev => [...prev, { 
        mission_id: mission.id, 
        completed_at: new Date().toISOString(), 
        stars_earned: 1 
      }]);

      const dayMissions = missionProgram.find(d => d.day === mission.day_number)?.missions || [];
      const allCompleted = dayMissions.every(m => completedIds.has(m.id) || m.id === mission.id);

      if (allCompleted && data?.user_progress) {
        setUserProgress(data.user_progress);
        if (data.user_progress.current_day > userProgress.current_day) {
          setNewlyUnlockedDay(data.user_progress.current_day);
          setShowDayCompleteModal(true);
          setNimiMood("proud");
          confetti({
            particleCount: 150,
            spread: 70,
            origin: { y: 0.6 }
          });
        }
      }
    } catch (error) {
      setCompletionError("Failed to complete mission. Please try again.");
      setNimiMood("default");
    } finally {
      setCompletingMissionId(null);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-purple-50 font-sans select-none">
      <Header />

      <AnimatePresence>
        {showDayCompleteModal && newlyUnlockedDay !== null && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="relative max-w-md w-full rounded-xl bg-white p-6 shadow-lg overflow-hidden"
              initial={{ scale: 0.85 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.85 }}
            >
              <div className="text-6xl mb-4 animate-pulse" aria-hidden="true">
                🏆
              </div>
              <h3 className="mb-2 text-center text-2xl font-bold">Day Complete!</h3>
              <p className="mb-6 text-center text-gray-700">
                You've completed Day {newlyUnlockedDay - 1}!
              </p>
              <div className="mb-6 rounded-lg border border-purple-200 bg-purple-50 p-4">
                <p className="text-purple-800 font-semibold">{streak}-day streak!</p>
                <p className="text-gray-600 mt-1 text-sm">Keep it going to earn bonus points!</p>
              </div>
              <Button
                onClick={() => {
                  setShowDayCompleteModal(false);
                  setSelectedDay(newlyUnlockedDay);
                  setNewlyUnlockedDay(null);
                }}
                className="flex w-full items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700"
              >
                Continue to Day {newlyUnlockedDay} <ChevronRight className="h-5 w-5" />
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {openVideo && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpenVideo(null)}
          >
            <video
              src={openVideo.video_url}
              controls
              autoPlay
              className="max-w-full max-h-[80vh] rounded-xl shadow-2xl"
              onClick={e => e.stopPropagation()}
              playsInline
              muted={false}
              preload="auto"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <main className="max-w-6xl mx-auto flex-grow px-4 py-8">
        {/* Greeting */}
        <section className="mb-8 text-center">
          <h1 className="text-5xl font-extrabold bg-gradient-to-r from-purple-700 to-pink-600 bg-clip-text text-transparent mb-4">
            Hello, {profile.full_name || "friend"}!
          </h1>
          <div className="inline-flex items-center bg-white rounded-full shadow px-6 py-2 mx-auto max-w-md gap-3">
            <p className="text-lg font-medium text-gray-700">{getMotivation()}</p>
          </div>
        </section>

        {/* Nimi Assistant */}
        <div className="max-w-4xl mx-auto mb-6">
          <NimiAssistant mood={nimiMood} />
        </div>

        {/* Progress Section */}
        <section className="mb-6 max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-semibold text-gray-700">Today's Progress</h2>
            <div className="flex items-center gap-2 bg-white rounded-full px-4 py-2 shadow">
              <Flame className="w-6 h-6 text-red-500" />
              <span className="font-semibold text-gray-700">{streak}-day streak</span>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="font-medium">Level {userProgress.level}</span>
                <span className="font-medium">
                  {userProgress.xp}/{xpNeededForNextLevel} XP
                </span>
              </div>
              <Progress
                value={levelProgress}
                className="h-3 rounded-full"
                indicatorClassName="bg-gradient-to-r from-yellow-400 to-yellow-600"
              />
            </div>

            <div>
              <Progress
                value={(dailyGoalProgress / DAILY_GOAL) * 100}
                className="h-3 rounded-full"
                indicatorClassName="bg-gradient-to-r from-blue-400 to-blue-600"
              />
              <div className="flex justify-between mt-1">
                <span className="font-medium">Daily Goal</span>
                <span className="font-medium">{dailyGoalProgress}/{DAILY_GOAL}</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-medium">Day Progress ({completedCount}/{totalMissions})</span>
                <span className="font-medium">{progressPercent}%</span>
              </div>
              <Progress
                value={progressPercent}
                className="h-3 rounded-full"
                indicatorClassName="bg-gradient-to-r from-purple-600 to-pink-600"
              />
            </div>
          </div>
        </section>

        {/* Day Selector */}
        <section className="mb-8 max-w-4xl mx-auto">
          <h3 className="mb-4 text-2xl font-semibold">Choose Adventure Day</h3>
          <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
            {missionProgram.map(day => {
              const dayLocked = isDayLocked(day.day);
              const allComplete = day.missions.every(m => completedIds.has(m.id));
              const selected = selectedDay === day.day;

              return (
                <button
                  key={day.day}
                  type="button"
                  disabled={dayLocked}
                  onClick={() => !dayLocked && setSelectedDay(day.day)}
                  className={`flex flex-col items-center py-4 rounded-xl transition ${
                    selected
                      ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white shadow-lg scale-105"
                      : dayLocked
                      ? "bg-gray-100 cursor-not-allowed text-gray-500"
                      : allComplete
                      ? "bg-green-50 border-2 border-green-400 shadow-inner text-green-800"
                      : "bg-white hover:bg-gray-50 shadow-sm text-gray-900"
                  }`}
                >
                  <span className="text-3xl">{dayLocked ? "🔒" : day.emoji}</span>
                  <span className="mt-1 font-semibold">Day {day.day}</span>
                  {allComplete && !dayLocked && (
                    <CheckCircle className="absolute top-1 right-1 w-5 h-5 text-green-500" />
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* Missions List */}
        {currentDayData ? (
          <section className="max-w-4xl mx-auto space-y-6">
            <div className="text-center">
              <h2 className="mb-2 text-3xl font-bold">{currentDayData.title}</h2>
              <div className="inline-flex items-center gap-3 text-lg font-semibold text-gray-700">
                <Calendar /> Theme: {currentDayData.theme}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {currentDayData.missions.map(mission => {
                const locked = isMissionLocked(mission);
                const completed = completedIds.has(mission.id);

                return (
                  <Card
                    key={mission.id}
                    className={`relative transition-shadow rounded-xl shadow-md ${
                      completed ? "bg-green-50 shadow-green-400" : "bg-white hover:shadow-lg"
                    } ${locked ? "opacity-70 cursor-not-allowed" : ""}`}
                  >
                    <CardHeader className="flex items-center gap-4 pb-4">
                      <div
                        className={`flex w-14 h-14 items-center justify-center rounded-full text-white ${
                          completed ? "bg-green-500" : "bg-pink-500"
                        }`}
                      >
                        {completed ? <CheckCircle className="w-8 h-8" /> : <Star className="w-8 h-8" />}
                      </div>
                      <CardTitle>{mission.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-3 text-gray-800">
                      <p>{mission.description}</p>
                      <div className="flex justify-around text-gray-600 text-sm">
                        <Badge className="flex items-center gap-1 bg-blue-100 px-3 py-1 rounded-full text-blue-700">
                          <Clock className="w-4 h-4" /> {mission.duration}
                        </Badge>
                        <Badge className="flex items-center gap-1 bg-purple-100 px-3 py-1 rounded-full text-purple-700">
                          <Star className="w-4 h-4" /> {mission.difficulty}
                        </Badge>
                      </div>
                    </CardContent>
                    <div className="p-6 pt-0 space-y-3">
                      <Button
                        disabled={locked}
                        onClick={() => !locked && setOpenVideo(mission)}
                        className="w-full"
                        variant="gradient"
                      >
                        <Play className="mr-2 w-5 h-5" /> Watch Video
                      </Button>
                      <Button
                        disabled={locked || completed || completingMissionId === mission.id}
                        onClick={() => !locked && !completed && completeMission(mission)}
                        className="w-full"
                        variant={completed ? "success" : locked ? "disabled" : "default"}
                      >
                        {completingMissionId === mission.id ? (
                          <>
                            <Loader2 className="animate-spin mr-2 h-5 w-5" /> Completing...
                          </>
                        ) : completed ? (
                          <>
                            <CheckCircle className="mr-2 h-5 w-5" /> Completed
                          </>
                        ) : locked ? (
                          <>
                            <Lock className="mr-2 h-5 w-5" /> Locked
                          </>
                        ) : (
                          "Complete Mission"
                        )}
                      </Button>
                      {completionError && completingMissionId === mission.id && (
                        <p className="mt-2 text-center text-red-600 text-sm">
                          {completionError}
                        </p>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          </section>
        ) : (
          <p className="text-center text-gray-500 mt-12">No missions found for this day.</p>
        )}

        {/* Storybook Section */}
        {storybook && (
          <section className="mt-12 max-w-4xl mx-auto">
            <Button
              onClick={() => setShowStorybook(!showStorybook)}
              variant="ghost"
              className="flex items-center gap-2 mb-4 mx-auto"
            >
              <BookOpen className="w-5 h-5" />
              <span className="text-lg font-semibold">
                {showStorybook ? "Hide Storybook" : "Show Storybook"}
              </span>
              <ChevronRight
                className={`w-5 h-5 transition-transform ${showStorybook ? "rotate-90" : ""}`}
              />
            </Button>

            <AnimatePresence>
              {showStorybook && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="bg-white p-6 rounded-xl shadow-lg whitespace-pre-line border-2 border-purple-100">
                    <h2 className="mb-4 text-3xl font-bold text-purple-700 flex items-center gap-2">
                      <Bookmark className="text-pink-500" /> {storybook.title}
                    </h2>
                    <div className="prose max-w-none">
                      {storybook.content}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        )}
      </main>

      <BottomNavigation />
      <Footer />
    </div>
  );
}