"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import supabase from "@/lib/supabaseClient";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function LoginPage() {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleLogin = async () => {
    if (!name || !password) return alert("Enter name and password");

    const { data, error } = await supabase
      .from("users")
      .select("*")
      .eq("name", name)
      .single();

    if (error || !data) {
      alert("User not found!");
    } else {
      localStorage.setItem("user_id", data.id);
      router.push("/");
    }
  };

  return (
    <div className="min-h-screen bg-blue-50 flex flex-col items-center justify-between">
      <Header />
      <main className="w-full max-w-md p-8 bg-white rounded-2xl shadow-lg text-center space-y-6">
        <h1 className="text-3xl font-bold text-blue-600">🔐 Log In</h1>

        <input
          className="w-full p-3 border rounded-lg text-lg"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          className="w-full p-3 border rounded-lg text-lg"
          placeholder="Your Password"
          type="text"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          className="w-full p-3 rounded-full bg-blue-500 text-white font-bold text-lg"
          onClick={handleLogin}
        >
          🚪 Enter
        </button>

        <p className="text-sm text-gray-600">
          Don’t have an account?{" "}
          <span
            onClick={() => router.push("/signup")}
            className="text-blue-600 underline cursor-pointer"
          >
            Sign up
          </span>
        </p>
      </main>
      <Footer />
    </div>
  );
}
