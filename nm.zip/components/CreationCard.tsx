import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2 } from "lucide-react";

export default function CreationCard({ creation, onLike, onComment }) {
  const [commentInput, setCommentInput] = useState("");

  return (
    <Card className="bg-white shadow-md rounded-lg p-4">
      <img
        src={creation.image_url}
        alt={creation.description}
        className="rounded-md w-full h-48 object-cover"
      />
      <CardContent>
        <h3 className="font-bold text-lg text-gray-800">{creation.description}</h3>
        <p className="text-sm text-gray-500">
          {creation.child_name}, {creation.age} yrs • {creation.mission}
        </p>
        <div className="flex items-center gap-2 my-2">
          <Badge>{creation.emoji}</Badge>
        </div>
        <div className="flex gap-3 mt-2">
          <Button onClick={() => onLike(creation.id)} size="sm">
            <Heart className="w-4 h-4 mr-1 text-red-500" />
            {creation.likes}
          </Button>
          <Button onClick={() => onComment(creation.id, commentInput)} size="sm">
            <MessageCircle className="w-4 h-4 mr-1 text-blue-500" />
            Comment
          </Button>
          <Button onClick={() => navigator.share?.({ title: creation.description, url: location.href })} size="sm">
            <Share2 className="w-4 h-4 mr-1 text-green-500" />
            Share
          </Button>
        </div>
        <input
          className="w-full border mt-2 px-2 py-1 text-sm rounded"
          placeholder="Write a comment..."
          value={commentInput}
          onChange={(e) => setCommentInput(e.target.value)}
        />
        {creation.comments?.length > 0 && (
          <div className="mt-3 text-sm text-gray-600">
            {creation.comments.map((c, i) => (
              <p key={i}>💬 {c}</p>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
